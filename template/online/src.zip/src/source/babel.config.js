module.exports = {
  presets: [['@elux', {ui: 'react'}]],
};
