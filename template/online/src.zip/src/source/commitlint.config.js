module.exports = {
  extends: ['@commitlint/config-conventional'],
  rules: {},
};
