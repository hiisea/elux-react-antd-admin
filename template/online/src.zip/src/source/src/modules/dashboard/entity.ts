export enum CurView {
  'workplace' = 'workplace',
}
