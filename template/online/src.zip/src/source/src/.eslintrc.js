module.exports = {
  root: true,
  extends: ['plugin:@elux/react'],
  env: {
    browser: true,
    node: true,
  },
};
